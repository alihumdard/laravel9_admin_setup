<footer class="bg-white border-t border-gray-200 py-4">
  <div class="max-w-7xl mx-auto px-4 text-center text-gray-600 text-sm">
    © 2025 Urban Night Media. All rights reserved. |
    <a href="#" class="text-blue-500 hover:underline">Privacy Policy</a> |
    <a href="#" class="text-blue-500 hover:underline">Terms & Conditions</a>
  </div>
</footer>
<?php /**PATH G:\Laravel\laravel9_setup\resources\views/includes/footer.blade.php ENDPATH**/ ?>